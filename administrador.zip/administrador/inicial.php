<?php

echo "pagina inicial";

?>
