<html>
<head>
<script src="../Jquery.js" type="text/jscript" ></script>

</head>
<body>
<center><p >Autor:</p>
  <input type="text" id="autor"/></br>
</p>
<p >Titulo da noticia:</p>
  <input type="text" id="titulo"/></br>
</p>
<p>Noticia:<br style="font-size:10px;">Lembre-se: A noticia deve conter mais de 50 caracteres</br><textarea id ='noticia' cols="70" rows="30"></textarea></p></br>
<input type="checkbox" id="check_visivel">Visível</input></br>
<input type="button" id='botao_add_noticia' value="Adicionar"/>
</center>
</body>
</html>