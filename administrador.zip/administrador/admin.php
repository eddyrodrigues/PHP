
<p><a href="?id=add_noticia"> Adicionar noticias </a></p>
